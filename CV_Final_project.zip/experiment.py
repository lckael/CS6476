#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Dec  2 21:05:33 2021

@author: cheng
"""

import cv2
import numpy as np
import os
import pandas as pd
import tsr
import sys
import warnings
warnings.filterwarnings("ignore")

def run_tsr(frame_path, render = False):
    input_dir = "archive"
    output_dir = "output"
    anno_dir = 'annotations_train' 
    frame_dir = os.path.join(input_dir, frame_path)
    size = (32, 32)
    X, y, le = tsr.load_anno(anno_dir, size)
    clf = tsr.train_clf_svm(X, y)
    
    img_list, filename_list = tsr.load_images_from_dir(frame_dir, ext=".png")
    anno_list = pd.read_csv(os.path.join(frame_dir, 'frameAnnotations.csv'), header = 0, sep = ';|,')
    
    columns_list = ['Filename', 'Annotation tag', 'Upper left corner X',
           'Upper left corner Y', 'Lower right corner X', 'Lower right corner Y']
    
    anno_list_test = anno_list.loc[anno_list['Annotation tag'].isin(['stop','signalAhead','stopAhead']),
                                   columns_list ]

    
    anno_list_pred = pd.DataFrame([], columns = columns_list)

    for idx, img_in in enumerate(img_list):
        img_copy = img_in.copy()
        img_copy = cv2.GaussianBlur(img_copy,(5,5),cv2.BORDER_DEFAULT)
        img_copy_norm = img_copy/img_copy.sum(axis=2, keepdims=1).astype(np.float64)
        img_copy_norm = np.nan_to_num(img_copy_norm)
        
        red = tsr.red_mask(img_copy_norm, img_copy)
        # blue = tsr.blue_mask(img_copy_norm, img_copy)
        yellow = tsr.yellow_mask(img_copy_norm, img_copy)
        mask_all = red | yellow
        pred_list, cordinates = tsr.contourList(img_in, mask_all, size, 0, 25)
        
        # ytest_pred = tsr.test_clf_pca(Xtrain_proj, ytrain, np.array(contours), eig_vecs)
        # labels = le.inverse_transform(ytest_pred)
        if pred_list:
            ytest_pred = clf.predict(pred_list)
            labels = le.inverse_transform(ytest_pred)
            for i, label in enumerate(labels):
                l,r,u,d = cordinates[i]
                tsr.place_text(label, ((l + r) // 2, (d + u) // 2), img_in, cache={})
                cv2.rectangle(img_in, (l, u), (r, d), (0,0,255), 1)
                anno_list_pred.loc[len(anno_list_pred.index)] = [filename_list[idx], label, l, u, r, d]
        if render:
            cv2.imshow('TSR', img_in)
            cv2.waitKey(1)
        cv2.imwrite(os.path.join(output_dir, filename_list[idx]), img_in)
    if render:    
        cv2.destroyAllWindows()
        
    join_anno = pd.merge(anno_list_pred, 
                      anno_list_test,  
                      how='inner', 
                      left_on=['Filename','Annotation tag',], 
                      right_on = ['Filename','Annotation tag'])
    join_anno = join_anno.drop_duplicates(['Filename','Annotation tag'])
    if anno_list_test.shape[0] > 0:
        print(frame_path.split('/')[0])
        print('traffic sign recognition rate is ' + str(round(100 * join_anno.shape[0] / anno_list_test.shape[0], 2)) + '%')
        print('False positive per frame is ' +  str(round((anno_list_pred.shape[0] - join_anno.shape[0]) 
                                                           / anno_list.shape[0], 2)))

if __name__ == "__main__":
    if len(sys.argv) == 1:
        for frame_path in ['vid0/frameAnnotations-vid_cmp2.avi_annotations',
                           'vid1/frameAnnotations-vid_cmp1.avi_annotations',
                           'vid2/frameAnnotations-vid_cmp2.avi_annotations',
                           'vid3/frameAnnotations-vid_cmp2.avi_annotations',
                           'vid4/frameAnnotations-vid_cmp2.avi_annotations',
                           'vid5/frameAnnotations-vid_cmp2.avi_annotations',
                           'vid6/frameAnnotations-MVI_0071.MOV_annotations',
                           'vid7/frameAnnotations-MVI_0119.MOV_annotations',
                           'vid8/frameAnnotations-MVI_0120.MOV_annotations',
                           'vid9/frameAnnotations-MVI_0121.MOV_annotations',
                           'vid10/frameAnnotations-MVI_0122.MOV_annotations',
                           'vid11/frameAnnotations-MVI_0123.MOV_annotations']:
            run_tsr(frame_path)
    else:
        sys.argv[1]
        frame_path = sys.argv[1]
        run_tsr(frame_path)

