#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Dec  1 11:15:50 2021

@author: cheng
"""
import cv2
import numpy as np
from sklearn import preprocessing
from sklearn.svm import LinearSVC
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
import os


# -- display utils
def place_text(text, center, img, cache={}):
    if "y_offset" in cache:
        cache["y_offset"] *= -1
    else:
        cache["y_offset"] = -10
    size = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
    y = center[1] + cache["y_offset"]
    if size[0][0] + center[0] > img.shape[1]:
        x = center[0] - size[0][0] - 5
    else:
        x = center[0] + 5
    cv2.rectangle(img, (x, y - size[0][1] - size[1]),
                  (x + size[0][0], y + size[0][1] - size[1]), (0, 0, 0),
                  -1)
    cv2.putText(img, text, (x, y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255),
                1)
    
def load_images_from_dir(data_dir, size=(24, 24), ext=".png"):
    imagesFiles = [f for f in os.listdir(data_dir) if f.endswith(ext)]
    imgs = [np.array(cv2.imread(os.path.join(data_dir, f))) for f in imagesFiles]
    # imgs = [cv2.resize(x, size) for x in imgs]

    return imgs, imagesFiles

def load_anno(pos_folder, size=(32, 32)):
    
    images_files = [f for f in os.listdir(pos_folder)]
    X, y = [], []
    for img in images_files:
        tmp = cv2.imread(os.path.join(pos_folder, img), 0)
        tmp = cv2.resize(tmp, size)
        tmp = tmp.flatten()
        X.append(tmp)
        y.append(img.split('_')[1])
    le = preprocessing.LabelEncoder()
    y = le.fit_transform(y)
    return np.array(X), np.array(y), le

def get_mean_sign(x):
    return x.mean(axis = 0)

def pca(X, k):

    X_tmp = X - get_mean_sign(X)
    M = np.dot(X_tmp.T, X_tmp)
    w, v = np.linalg.eigh(M)
    return v[:,::-1][:, :k], w[::-1][:k]

def euclidean_distance(p0, p1):

    return np.sqrt(np.power(p0[0] - p1[0], 2) + np.power(p0[1] - p1[1], 2))    
    
# PCA training #######################################################################

def train_clf_pca(Xtrain, k = 10): 
    eig_vecs, eig_vals = pca(Xtrain, k)
    mu = get_mean_sign(Xtrain)
    Xtrain_proj = np.dot(Xtrain - mu, eig_vecs)
    return eig_vecs, Xtrain_proj

# testing
def test_clf_pca(Xtrain_proj, ytrain, Xtest, eig_vecs):
    mu = get_mean_sign(Xtest)
    Xtest_proj = np.dot(Xtest - mu, eig_vecs)
    y_pred = []
    for i, obs in enumerate(Xtest_proj):   
        dist = [np.linalg.norm(obs - x) for x in Xtrain_proj]
        idx = np.argmin(dist)
        y_pred.append(ytrain[idx])
    return y_pred
# SVM training #######################################################################
def train_clf_svm(X, y):
    clf = make_pipeline(StandardScaler(), LinearSVC(random_state = 0, tol = 1e-5))
    clf.fit(X, y)
    return clf
    
######################################################################################
def red_mask(img_norm, img):
    mask_red = img_norm[:,:,2] >= 0.4
    mask_green = img_norm[:,:,1] <= 0.3
    mask = mask_red * mask_green
    return mask


def blue_mask(img_norm, img):
    mask= img_norm[:,:,0] >= 0.4
    return mask
    
def yellow_mask(img_norm, img):
    mask = img_norm[:,:,2] + img_norm[:,:,1] >= 0.85
    return mask

def contourList(img_origin, mask, size, margin = 0, minContourSize = 36):
    img = img_origin.copy()
    img[~mask] = [0,0,0]
    edges = cv2.Canny(img, 100, 200)
    contours, hierarchy = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    pred_list = []
    corner_list = []
    for contour in contours:
        if cv2.contourArea(contour) >= minContourSize:
            l, u = contour.min(axis = 0).reshape(2,)
            r, d = contour.max(axis = 0).reshape(2,)
            # cv2.rectangle(img_in, (l, u), (r, d), (0,255,0), 2)
            if d - u > 5 and r - l > 5 and (r - l) / (d - u) < 1.5 and (r - l) / (d - u) > 2/3:
                # contour_list.append(contour)
                tmp = cv2.cvtColor(img[max(0, u - margin) : min(d + margin, img.shape[0]), 
                                       max(0, l - margin) : min(r + margin, img.shape[1])], cv2.COLOR_BGR2GRAY)
                tmp = cv2.resize(tmp, size)
                tmp = tmp.flatten()
                pred_list.append(tmp)
                corner_list.append((max(0, l - margin),min(r + margin, img.shape[1]),max(0, u - margin),min(d + margin, img.shape[0])))
            # corner_list.append(((l + r) // 2, (d + u) // 2))            
    return pred_list, corner_list



if __name__ == "__main__":
    pass



